pubcoder.projectID = pubcoder.projectID || "F352EBED3560564A9B0BC9067C8E6D31";
pubcoder.project.id = pubcoder.project.id || "F352EBED3560564A9B0BC9067C8E6D31";
pubcoder.project.title = pubcoder.project.title || "Namgay\'s Project";
pubcoder.page.id = pubcoder.page.id || 344;
pubcoder.page.title = pubcoder.page.title || "1";
pubcoder.page.number = pubcoder.page.number || 2;
pubcoder.page.alias = pubcoder.page.alias || "";


var ua = navigator.userAgent.toLowerCase();
var touchDownEvent;
var touchUpEvent;
var isMobile;
var aigX = 0, aigY = 0;
var askAudioPermission = false;



/*
 * 
 * Init Action Lists
 *
 * 
 */
var obj778_onTap_activeActionGroupIndex = -1;
var obj778_onTap_runningActionsCount = 0;
var obj778_onTap_loopCount = 0;
var obj781_onTap_activeActionGroupIndex = -1;
var obj781_onTap_runningActionsCount = 0;
var obj781_onTap_loopCount = 0;
var obj784_onTap_activeActionGroupIndex = -1;
var obj784_onTap_runningActionsCount = 0;
var obj784_onTap_loopCount = 0;
var obj787_onTap_activeActionGroupIndex = -1;
var obj787_onTap_runningActionsCount = 0;
var obj787_onTap_loopCount = 0;
var obj790_onTap_activeActionGroupIndex = -1;
var obj790_onTap_runningActionsCount = 0;
var obj790_onTap_loopCount = 0;
var obj871_onTap_activeActionGroupIndex = -1;
var obj871_onTap_runningActionsCount = 0;
var obj871_onTap_loopCount = 0;
var obj903_onTap_activeActionGroupIndex = -1;
var obj903_onTap_runningActionsCount = 0;
var obj903_onTap_loopCount = 0;
var obj1645_onTap_activeActionGroupIndex = -1;
var obj1645_onTap_runningActionsCount = 0;
var obj1645_onTap_loopCount = 0;

/*
 * 
 * Init SCCounter
 *
 * 
 */
 

 $(window).on(PubCoder.Events.PageLoad, function(){
	window.eventObj = {};
	/*
	 * 
	 * Init SCAnimation
	 * 
	 * 
	 */
	

	/*
	 *
	 *   Init Shake
	 *
	 */
	window.addEventListener('shake', function () {
		
	}, false);
	
	/*
	 *
	 *   Init Masked Images
	 *
	 */
	 

 	/*
	 * 
	 * Init SCPhotogallery
	 * 
	 * 
	 */
	

 	/*
	 * 
	 * Init SCQuizMulti
	 * 
	 * 
	 */
	

 	/*
	 * 
	 * Init SCDrawer
	 * 
	 * 
	 */
	
    
 	/*
	 * 
	 * Init SCWPanZoom
	 * 
	 * 
	 */
	
    
 	/*
	 * 
	 * Init SCWMemoryGame
	 * 
	 * 
	 */
	

	/*
	 * 
	 * Init SCCrosswords
	 * 
	 * 
	 */
	

	/*
	 * 
	 * Init SCFillInTheGaps
	 * 
	 * 
	 */
	

	/*
	 * 
	 * Init SCTrueFalse
	 * 
	 * 
	 */
	
	
	/*
	 * 
	 * Init SCMatchWordWithPicture
	 * 
	 * 
	 */
	
    
    

	if(! navigator.userAgent.match(/PubCoderHelper/i)) {
		/*
		 *
	 	 *   Action Groups
	 	 *
	 	 */
		
obj778_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj778_onTap_activeActionGroupIndex = -1;
		$("#obj778").trigger("obj778_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 778) {
				console.warn("de-queueing event obj778." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj778").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj778_onTap_activeActionGroupIndex = 0;
	


//	action: show 
//	selector: #obj897
(function(){
	window.obj778_onTap_runningActionsCount = obj778_onTap_runningActionsCount + 1;


	var selector = "#obj897";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup1();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup1();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj778_onTap_actionGroup1 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj778_onTap_activeActionGroupIndex = -1;
		$("#obj778").trigger("obj778_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 778) {
				console.warn("de-queueing event obj778." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj778").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj778_onTap_activeActionGroupIndex = 1;
	

//	action: hide
//	selector: obj#obj778 
hide_906();
function hide_906() {
	var selector = "#obj778";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj778_onTap_runningActionsCount = obj778_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup2();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_906(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup2();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj778_onTap_actionGroup2 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj778_onTap_activeActionGroupIndex = -1;
		$("#obj778").trigger("obj778_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 778) {
				console.warn("de-queueing event obj778." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj778").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj778_onTap_activeActionGroupIndex = 2;
	

//	action: hide
//	selector: obj#obj742 
hide_907();
function hide_907() {
	var selector = "#obj742";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj778_onTap_runningActionsCount = obj778_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup3();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_907(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup3();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj778_onTap_actionGroup3 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj778_onTap_activeActionGroupIndex = -1;
		$("#obj778").trigger("obj778_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 778) {
				console.warn("de-queueing event obj778." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj778").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj778_onTap_activeActionGroupIndex = 3;
	


//	action: show 
//	selector: #obj903
(function(){
	window.obj778_onTap_runningActionsCount = obj778_onTap_runningActionsCount + 1;


	var selector = "#obj903";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup4();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj778_onTap_runningActionsCount = window.obj778_onTap_runningActionsCount - 1;

if (window.obj778_onTap_runningActionsCount < 0) {
	window.obj778_onTap_runningActionsCount = 0;
} else if (window.obj778_onTap_runningActionsCount == 0) {
	obj778_onTap_actionGroup4();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj778_onTap_actionGroup4 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj778_onTap_activeActionGroupIndex = -1;
		$("#obj778").trigger("obj778_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 778) {
				console.warn("de-queueing event obj778." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj778").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj778_onTap_activeActionGroupIndex = 4;
	











































};
obj781_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj781_onTap_activeActionGroupIndex = -1;
		$("#obj781").trigger("obj781_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 781) {
				console.warn("de-queueing event obj781." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj781").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj781_onTap_activeActionGroupIndex = 0;
	
//	action: goToPage
goToPage_927();
function goToPage_927() {
	window.obj781_onTap_runningActionsCount = obj781_onTap_runningActionsCount + 1;

	$("#anchor20")[0].click();
	window.obj781_onTap_runningActionsCount = window.obj781_onTap_runningActionsCount - 1;

if (window.obj781_onTap_runningActionsCount < 0) {
	window.obj781_onTap_runningActionsCount = 0;
} else if (window.obj781_onTap_runningActionsCount == 0) {
	obj781_onTap_actionGroup1();
}
}










































};
obj781_onTap_actionGroup1 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj781_onTap_activeActionGroupIndex = -1;
		$("#obj781").trigger("obj781_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 781) {
				console.warn("de-queueing event obj781." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj781").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj781_onTap_activeActionGroupIndex = 1;
	











































};
obj784_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj784_onTap_activeActionGroupIndex = -1;
		$("#obj784").trigger("obj784_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 784) {
				console.warn("de-queueing event obj784." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj784").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj784_onTap_activeActionGroupIndex = 0;
	
//	action: goToPage
goToPage_929();
function goToPage_929() {
	window.obj784_onTap_runningActionsCount = obj784_onTap_runningActionsCount + 1;

	$("#anchor21")[0].click();
	window.obj784_onTap_runningActionsCount = window.obj784_onTap_runningActionsCount - 1;

if (window.obj784_onTap_runningActionsCount < 0) {
	window.obj784_onTap_runningActionsCount = 0;
} else if (window.obj784_onTap_runningActionsCount == 0) {
	obj784_onTap_actionGroup1();
}
}










































};
obj784_onTap_actionGroup1 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj784_onTap_activeActionGroupIndex = -1;
		$("#obj784").trigger("obj784_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 784) {
				console.warn("de-queueing event obj784." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj784").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj784_onTap_activeActionGroupIndex = 1;
	











































};
obj787_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj787_onTap_activeActionGroupIndex = -1;
		$("#obj787").trigger("obj787_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 787) {
				console.warn("de-queueing event obj787." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj787").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj787_onTap_activeActionGroupIndex = 0;
	
//	action: goToPage
goToPage_923();
function goToPage_923() {
	window.obj787_onTap_runningActionsCount = obj787_onTap_runningActionsCount + 1;

	$("#anchor22")[0].click();
	window.obj787_onTap_runningActionsCount = window.obj787_onTap_runningActionsCount - 1;

if (window.obj787_onTap_runningActionsCount < 0) {
	window.obj787_onTap_runningActionsCount = 0;
} else if (window.obj787_onTap_runningActionsCount == 0) {
	obj787_onTap_actionGroup1();
}
}










































};
obj787_onTap_actionGroup1 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj787_onTap_activeActionGroupIndex = -1;
		$("#obj787").trigger("obj787_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 787) {
				console.warn("de-queueing event obj787." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj787").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj787_onTap_activeActionGroupIndex = 1;
	











































};
obj790_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj790_onTap_activeActionGroupIndex = -1;
		$("#obj790").trigger("obj790_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 790) {
				console.warn("de-queueing event obj790." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj790").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj790_onTap_activeActionGroupIndex = 0;
	


//	action: show 
//	selector: #obj1582
(function(){
	window.obj790_onTap_runningActionsCount = obj790_onTap_runningActionsCount + 1;


	var selector = "#obj1582";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup1();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup1();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj790_onTap_actionGroup1 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj790_onTap_activeActionGroupIndex = -1;
		$("#obj790").trigger("obj790_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 790) {
				console.warn("de-queueing event obj790." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj790").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj790_onTap_activeActionGroupIndex = 1;
	







//	action: playMovie
//	target: obj1582 
playMovie_1652();
function playMovie_1652() {
	window.obj790_onTap_runningActionsCount = obj790_onTap_runningActionsCount + 1;

	var myVideo = $("#obj1582")[0];
	var playFromBeginning = true;
	var waitForCompletion = false;
	var doFullscreen = false;
	if (playFromBeginning) myVideo.currentTime = 0;
	myVideo.play();
	try {
		if (doFullscreen) {
			function scheduleFullscreen(msec, tries) {
				if (typeof(tries) === "undefined") {
					tries = 1;
				} else if (tries > 5) return;

				var fn;
				if (myVideo.requestFullscreen) {
					console.warn("requestFullscreen;");
					fn = myVideo.requestFullscreen;
				} else if (myVideo.mozRequestFullScreen) {
					console.warn("mozRequestFullScreen;");
					fn = myVideo.mozRequestFullScreen;
				} else if (myVideo.webkitRequestFullscreen) {
					console.warn("webkitRequestFullscreen;");
					fn = myVideo.webkitRequestFullscreen;
				} else if (myVideo.msRequestFullscreen) {
					console.warn("msRequestFullscreen;");
					fn = myVideo.msRequestFullscreen;
				} else if (myVideo.webkitEnterFullscreen) {
					console.warn("webkitEnterFullscreen");
					fn = myVideo.webkitEnterFullscreen
				} else {
					console.warn("no fullscreen support");
					return;
				}
				if (fn == myVideo.webkitEnterFullscreen) {
					try {
						fn.call(myVideo);
					} catch (error) {
						scheduleFullscreen(1000, tries++);
					}
				} else {
					fn.call(myVideo).catch(function (err) { scheduleFullscreen(1000, tries++); });
				}
			}
			scheduleFullscreen(0);
		}
	} catch (error) {
		// do nothing, just don't go fullscreen
	}
	if (waitForCompletion) {
		var actionEnded = function() {
			this.removeEventListener('pause',arguments.callee,false);
			this.removeEventListener('ended',arguments.callee,false);
		    window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup2();
}
		};
		// myVideo.addEventListener('pause', actionEnded, false);
		myVideo.addEventListener('ended', actionEnded, false);
	} else {
		window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup2();
}
	}
}



































};
obj790_onTap_actionGroup2 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj790_onTap_activeActionGroupIndex = -1;
		$("#obj790").trigger("obj790_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 790) {
				console.warn("de-queueing event obj790." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj790").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj790_onTap_activeActionGroupIndex = 2;
	

//	action: hide
//	selector: obj#obj790 
hide_1653();
function hide_1653() {
	var selector = "#obj790";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj790_onTap_runningActionsCount = obj790_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup3();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_1653(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup3();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj790_onTap_actionGroup3 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj790_onTap_activeActionGroupIndex = -1;
		$("#obj790").trigger("obj790_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 790) {
				console.warn("de-queueing event obj790." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj790").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj790_onTap_activeActionGroupIndex = 3;
	


//	action: show 
//	selector: #obj1645
(function(){
	window.obj790_onTap_runningActionsCount = obj790_onTap_runningActionsCount + 1;


	var selector = "#obj1645";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup4();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj790_onTap_runningActionsCount = window.obj790_onTap_runningActionsCount - 1;

if (window.obj790_onTap_runningActionsCount < 0) {
	window.obj790_onTap_runningActionsCount = 0;
} else if (window.obj790_onTap_runningActionsCount == 0) {
	obj790_onTap_actionGroup4();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj790_onTap_actionGroup4 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj790_onTap_activeActionGroupIndex = -1;
		$("#obj790").trigger("obj790_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 790) {
				console.warn("de-queueing event obj790." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj790").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj790_onTap_activeActionGroupIndex = 4;
	











































};
obj871_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj871_onTap_activeActionGroupIndex = -1;
		$("#obj871").trigger("obj871_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 871) {
				console.warn("de-queueing event obj871." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj871").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj871_onTap_activeActionGroupIndex = 0;
	
//	action: goToPage
goToPage_901();
function goToPage_901() {
	window.obj871_onTap_runningActionsCount = obj871_onTap_runningActionsCount + 1;

	$("#anchor23")[0].click();
	window.obj871_onTap_runningActionsCount = window.obj871_onTap_runningActionsCount - 1;

if (window.obj871_onTap_runningActionsCount < 0) {
	window.obj871_onTap_runningActionsCount = 0;
} else if (window.obj871_onTap_runningActionsCount == 0) {
	obj871_onTap_actionGroup1();
}
}










































};
obj871_onTap_actionGroup1 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj871_onTap_activeActionGroupIndex = -1;
		$("#obj871").trigger("obj871_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 871) {
				console.warn("de-queueing event obj871." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj871").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj871_onTap_activeActionGroupIndex = 1;
	











































};
obj903_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj903_onTap_activeActionGroupIndex = -1;
		$("#obj903").trigger("obj903_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 903) {
				console.warn("de-queueing event obj903." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj903").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj903_onTap_activeActionGroupIndex = 0;
	

//	action: hide
//	selector: obj#obj897 
hide_909();
function hide_909() {
	var selector = "#obj897";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj903_onTap_runningActionsCount = obj903_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup1();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_909(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup1();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj903_onTap_actionGroup1 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj903_onTap_activeActionGroupIndex = -1;
		$("#obj903").trigger("obj903_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 903) {
				console.warn("de-queueing event obj903." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj903").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj903_onTap_activeActionGroupIndex = 1;
	


//	action: show 
//	selector: #obj742
(function(){
	window.obj903_onTap_runningActionsCount = obj903_onTap_runningActionsCount + 1;


	var selector = "#obj742";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup2();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup2();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj903_onTap_actionGroup2 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj903_onTap_activeActionGroupIndex = -1;
		$("#obj903").trigger("obj903_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 903) {
				console.warn("de-queueing event obj903." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj903").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj903_onTap_activeActionGroupIndex = 2;
	

//	action: hide
//	selector: obj#obj903 
hide_911();
function hide_911() {
	var selector = "#obj903";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj903_onTap_runningActionsCount = obj903_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup3();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_911(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup3();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj903_onTap_actionGroup3 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj903_onTap_activeActionGroupIndex = -1;
		$("#obj903").trigger("obj903_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 903) {
				console.warn("de-queueing event obj903." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj903").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj903_onTap_activeActionGroupIndex = 3;
	


//	action: show 
//	selector: #obj778
(function(){
	window.obj903_onTap_runningActionsCount = obj903_onTap_runningActionsCount + 1;


	var selector = "#obj778";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup4();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj903_onTap_runningActionsCount = window.obj903_onTap_runningActionsCount - 1;

if (window.obj903_onTap_runningActionsCount < 0) {
	window.obj903_onTap_runningActionsCount = 0;
} else if (window.obj903_onTap_runningActionsCount == 0) {
	obj903_onTap_actionGroup4();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj903_onTap_actionGroup4 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj903_onTap_activeActionGroupIndex = -1;
		$("#obj903").trigger("obj903_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 903) {
				console.warn("de-queueing event obj903." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj903").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj903_onTap_activeActionGroupIndex = 4;
	











































};
obj1645_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1645_onTap_activeActionGroupIndex = -1;
		$("#obj1645").trigger("obj1645_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1645) {
				console.warn("de-queueing event obj1645." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1645").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1645_onTap_activeActionGroupIndex = 0;
	









//	action: stopMovie 
//	target: obj1582 
stopMovie_1647();
function stopMovie_1647() {
	window.obj1645_onTap_runningActionsCount = obj1645_onTap_runningActionsCount + 1;

	var myVideo = $("#obj1582")[0];
	myVideo.pause();
	window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup1();
}
}

































};
obj1645_onTap_actionGroup1 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1645_onTap_activeActionGroupIndex = -1;
		$("#obj1645").trigger("obj1645_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1645) {
				console.warn("de-queueing event obj1645." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1645").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1645_onTap_activeActionGroupIndex = 1;
	

//	action: hide
//	selector: obj#obj1582 
hide_1648();
function hide_1648() {
	var selector = "#obj1582";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj1645_onTap_runningActionsCount = obj1645_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup2();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_1648(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup2();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj1645_onTap_actionGroup2 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1645_onTap_activeActionGroupIndex = -1;
		$("#obj1645").trigger("obj1645_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1645) {
				console.warn("de-queueing event obj1645." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1645").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1645_onTap_activeActionGroupIndex = 2;
	

//	action: hide
//	selector: obj#obj1645 
hide_1649();
function hide_1649() {
	var selector = "#obj1645";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj1645_onTap_runningActionsCount = obj1645_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup3();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_1649(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup3();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj1645_onTap_actionGroup3 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1645_onTap_activeActionGroupIndex = -1;
		$("#obj1645").trigger("obj1645_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1645) {
				console.warn("de-queueing event obj1645." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1645").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1645_onTap_activeActionGroupIndex = 3;
	


//	action: show 
//	selector: #obj790
(function(){
	window.obj1645_onTap_runningActionsCount = obj1645_onTap_runningActionsCount + 1;


	var selector = "#obj790";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup4();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj1645_onTap_runningActionsCount = window.obj1645_onTap_runningActionsCount - 1;

if (window.obj1645_onTap_runningActionsCount < 0) {
	window.obj1645_onTap_runningActionsCount = 0;
} else if (window.obj1645_onTap_runningActionsCount == 0) {
	obj1645_onTap_actionGroup4();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj1645_onTap_actionGroup4 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj1645_onTap_activeActionGroupIndex = -1;
		$("#obj1645").trigger("obj1645_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1645) {
				console.warn("de-queueing event obj1645." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1645").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1645_onTap_activeActionGroupIndex = 4;
	











































};
		

		/*
		 *
	 	 *  Events
	 	 *
	 	 */
		

















































































/*
 *
 *   obj778: Event Touch Down
 *
 */

$("#obj778").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj778_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj778_onTap is still running");
	return;
}
var obj778_onTap_runningActionsCount = 0;
var obj778_onTap_loopCount = 0;
obj778_onTap_actionGroup0();
});


















/*
 *
 *   obj781: Event Touch Down
 *
 */

$("#obj781").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj781_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj781_onTap is still running");
	return;
}
var obj781_onTap_runningActionsCount = 0;
var obj781_onTap_loopCount = 0;
obj781_onTap_actionGroup0();
});


















/*
 *
 *   obj784: Event Touch Down
 *
 */

$("#obj784").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj784_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj784_onTap is still running");
	return;
}
var obj784_onTap_runningActionsCount = 0;
var obj784_onTap_loopCount = 0;
obj784_onTap_actionGroup0();
});


















/*
 *
 *   obj787: Event Touch Down
 *
 */

$("#obj787").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj787_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj787_onTap is still running");
	return;
}
var obj787_onTap_runningActionsCount = 0;
var obj787_onTap_loopCount = 0;
obj787_onTap_actionGroup0();
});


















/*
 *
 *   obj790: Event Touch Down
 *
 */

$("#obj790").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj790_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj790_onTap is still running");
	return;
}
var obj790_onTap_runningActionsCount = 0;
var obj790_onTap_loopCount = 0;
obj790_onTap_actionGroup0();
});


















/*
 *
 *   obj871: Event Touch Down
 *
 */

$("#obj871").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj871_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj871_onTap is still running");
	return;
}
var obj871_onTap_runningActionsCount = 0;
var obj871_onTap_loopCount = 0;
obj871_onTap_actionGroup0();
});





































/*
 *
 *   obj903: Event Touch Down
 *
 */

$("#obj903").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj903_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj903_onTap is still running");
	return;
}
var obj903_onTap_runningActionsCount = 0;
var obj903_onTap_loopCount = 0;
obj903_onTap_actionGroup0();
});





































/*
 *
 *   obj1645: Event Touch Down
 *
 */

$("#obj1645").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj1645_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj1645_onTap is still running");
	return;
}
var obj1645_onTap_runningActionsCount = 0;
var obj1645_onTap_loopCount = 0;
obj1645_onTap_actionGroup0();
});













































































































		
		
		/*
		 *
	 	 *  Page is ready to be played
	 	 *
	 	 */
		XPUB.ready();
	 }
});

$(window).on(pubcoder.events.pagePlay, function() {
	$(window).trigger(pubcoder.events.pageReady);
	if (pubcoder.isInteractionObserverSupported) {
		var ob = new IntersectionObserver(function(entries) {
			$(entries).each(function (index, entry) {
				if (entry.isIntersecting) {
					$(entry.target).trigger(pubcoder.events.appear);
				} else {
					$(entry.target).trigger(pubcoder.events.disappear);
				}
			});
		}, {
			root: null,
			rootMargin: "0px",
			threshold: 0
		});
		$(".SCView").each(function (i, el) {
			ob.observe(el);
		});	
	}
	
$("#obj792").trigger('SCEventShow');
$("#obj359").trigger('SCEventShow');
$("#obj742").trigger('SCEventShow');
$("#obj775").trigger('SCEventShow');
$("#obj778").trigger('SCEventShow');
$("#obj781").trigger('SCEventShow');
$("#obj784").trigger('SCEventShow');
$("#obj787").trigger('SCEventShow');
$("#obj790").trigger('SCEventShow');
$("#obj871").trigger('SCEventShow');
$("#obj7613").trigger('SCEventShow');
$("#obj7834").trigger('SCEventShow');
$("#obj7836").trigger('SCEventShow');
$("#obj7838").trigger('SCEventShow');
$("#obj7840").trigger('SCEventShow');
	

});