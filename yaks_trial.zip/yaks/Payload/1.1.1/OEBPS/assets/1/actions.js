pubcoder.projectID = pubcoder.projectID || "F352EBED3560564A9B0BC9067C8E6D31";
pubcoder.project.id = pubcoder.project.id || "F352EBED3560564A9B0BC9067C8E6D31";
pubcoder.project.title = pubcoder.project.title || "Namgay\'s Project";
pubcoder.page.id = pubcoder.page.id || 2;
pubcoder.page.title = pubcoder.page.title || "1";
pubcoder.page.number = pubcoder.page.number || 1;
pubcoder.page.alias = pubcoder.page.alias || "";


var ua = navigator.userAgent.toLowerCase();
var touchDownEvent;
var touchUpEvent;
var isMobile;
var aigX = 0, aigY = 0;
var askAudioPermission = false;



/*
 * 
 * Init Action Lists
 *
 * 
 */
var obj883_onTap_activeActionGroupIndex = -1;
var obj883_onTap_runningActionsCount = 0;
var obj883_onTap_loopCount = 0;
var obj889_onTap_activeActionGroupIndex = -1;
var obj889_onTap_runningActionsCount = 0;
var obj889_onTap_loopCount = 0;
var obj1569_onTap_activeActionGroupIndex = -1;
var obj1569_onTap_runningActionsCount = 0;
var obj1569_onTap_loopCount = 0;

/*
 * 
 * Init SCCounter
 *
 * 
 */
 

 $(window).on(PubCoder.Events.PageLoad, function(){
	window.eventObj = {};
	/*
	 * 
	 * Init SCAnimation
	 * 
	 * 
	 */
	

	/*
	 *
	 *   Init Shake
	 *
	 */
	window.addEventListener('shake', function () {
		
	}, false);
	
	/*
	 *
	 *   Init Masked Images
	 *
	 */
	 

 	/*
	 * 
	 * Init SCPhotogallery
	 * 
	 * 
	 */
	

 	/*
	 * 
	 * Init SCQuizMulti
	 * 
	 * 
	 */
	

 	/*
	 * 
	 * Init SCDrawer
	 * 
	 * 
	 */
	
    
 	/*
	 * 
	 * Init SCWPanZoom
	 * 
	 * 
	 */
	
    
 	/*
	 * 
	 * Init SCWMemoryGame
	 * 
	 * 
	 */
	

	/*
	 * 
	 * Init SCCrosswords
	 * 
	 * 
	 */
	

	/*
	 * 
	 * Init SCFillInTheGaps
	 * 
	 * 
	 */
	

	/*
	 * 
	 * Init SCTrueFalse
	 * 
	 * 
	 */
	
	
	/*
	 * 
	 * Init SCMatchWordWithPicture
	 * 
	 * 
	 */
	
    
    

	if(! navigator.userAgent.match(/PubCoderHelper/i)) {
		/*
		 *
	 	 *   Action Groups
	 	 *
	 	 */
		
obj883_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj883_onTap_activeActionGroupIndex = -1;
		$("#obj883").trigger("obj883_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 883) {
				console.warn("de-queueing event obj883." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj883").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj883_onTap_activeActionGroupIndex = 0;
	
//	action: goToPage
goToPage_896();
function goToPage_896() {
	window.obj883_onTap_runningActionsCount = obj883_onTap_runningActionsCount + 1;

	$("#anchor16")[0].click();
	window.obj883_onTap_runningActionsCount = window.obj883_onTap_runningActionsCount - 1;

if (window.obj883_onTap_runningActionsCount < 0) {
	window.obj883_onTap_runningActionsCount = 0;
} else if (window.obj883_onTap_runningActionsCount == 0) {
	obj883_onTap_actionGroup1();
}
}










































};
obj883_onTap_actionGroup1 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj883_onTap_activeActionGroupIndex = -1;
		$("#obj883").trigger("obj883_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 883) {
				console.warn("de-queueing event obj883." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj883").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj883_onTap_activeActionGroupIndex = 1;
	











































};
obj889_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj889_onTap_activeActionGroupIndex = -1;
		$("#obj889").trigger("obj889_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 889) {
				console.warn("de-queueing event obj889." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj889").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj889_onTap_activeActionGroupIndex = 0;
	


//	action: show 
//	selector: #obj1566
(function(){
	window.obj889_onTap_runningActionsCount = obj889_onTap_runningActionsCount + 1;


	var selector = "#obj1566";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup1();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup1();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();




//	action: playMovie
//	target: obj1566 
playMovie_1564();
function playMovie_1564() {
	window.obj889_onTap_runningActionsCount = obj889_onTap_runningActionsCount + 1;

	var myVideo = $("#obj1566")[0];
	var playFromBeginning = true;
	var waitForCompletion = false;
	var doFullscreen = false;
	if (playFromBeginning) myVideo.currentTime = 0;
	myVideo.play();
	try {
		if (doFullscreen) {
			function scheduleFullscreen(msec, tries) {
				if (typeof(tries) === "undefined") {
					tries = 1;
				} else if (tries > 5) return;

				var fn;
				if (myVideo.requestFullscreen) {
					console.warn("requestFullscreen;");
					fn = myVideo.requestFullscreen;
				} else if (myVideo.mozRequestFullScreen) {
					console.warn("mozRequestFullScreen;");
					fn = myVideo.mozRequestFullScreen;
				} else if (myVideo.webkitRequestFullscreen) {
					console.warn("webkitRequestFullscreen;");
					fn = myVideo.webkitRequestFullscreen;
				} else if (myVideo.msRequestFullscreen) {
					console.warn("msRequestFullscreen;");
					fn = myVideo.msRequestFullscreen;
				} else if (myVideo.webkitEnterFullscreen) {
					console.warn("webkitEnterFullscreen");
					fn = myVideo.webkitEnterFullscreen
				} else {
					console.warn("no fullscreen support");
					return;
				}
				if (fn == myVideo.webkitEnterFullscreen) {
					try {
						fn.call(myVideo);
					} catch (error) {
						scheduleFullscreen(1000, tries++);
					}
				} else {
					fn.call(myVideo).catch(function (err) { scheduleFullscreen(1000, tries++); });
				}
			}
			scheduleFullscreen(0);
		}
	} catch (error) {
		// do nothing, just don't go fullscreen
	}
	if (waitForCompletion) {
		var actionEnded = function() {
			this.removeEventListener('pause',arguments.callee,false);
			this.removeEventListener('ended',arguments.callee,false);
		    window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup1();
}
		};
		// myVideo.addEventListener('pause', actionEnded, false);
		myVideo.addEventListener('ended', actionEnded, false);
	} else {
		window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup1();
}
	}
}



































};
obj889_onTap_actionGroup1 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj889_onTap_activeActionGroupIndex = -1;
		$("#obj889").trigger("obj889_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 889) {
				console.warn("de-queueing event obj889." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj889").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj889_onTap_activeActionGroupIndex = 1;
	

//	action: hide
//	selector: obj#obj889 
hide_1573();
function hide_1573() {
	var selector = "#obj889";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj889_onTap_runningActionsCount = obj889_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup2();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_1573(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup2();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj889_onTap_actionGroup2 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj889_onTap_activeActionGroupIndex = -1;
		$("#obj889").trigger("obj889_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 889) {
				console.warn("de-queueing event obj889." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj889").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj889_onTap_activeActionGroupIndex = 2;
	


//	action: show 
//	selector: #obj1569
(function(){
	window.obj889_onTap_runningActionsCount = obj889_onTap_runningActionsCount + 1;


	var selector = "#obj1569";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup3();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj889_onTap_runningActionsCount = window.obj889_onTap_runningActionsCount - 1;

if (window.obj889_onTap_runningActionsCount < 0) {
	window.obj889_onTap_runningActionsCount = 0;
} else if (window.obj889_onTap_runningActionsCount == 0) {
	obj889_onTap_actionGroup3();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj889_onTap_actionGroup3 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj889_onTap_activeActionGroupIndex = -1;
		$("#obj889").trigger("obj889_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 889) {
				console.warn("de-queueing event obj889." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj889").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj889_onTap_activeActionGroupIndex = 3;
	











































};
obj1569_onTap_actionGroup0 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1569_onTap_activeActionGroupIndex = -1;
		$("#obj1569").trigger("obj1569_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1569) {
				console.warn("de-queueing event obj1569." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1569").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1569_onTap_activeActionGroupIndex = 0;
	









//	action: stopMovie 
//	target: obj1566 
stopMovie_1578();
function stopMovie_1578() {
	window.obj1569_onTap_runningActionsCount = obj1569_onTap_runningActionsCount + 1;

	var myVideo = $("#obj1566")[0];
	myVideo.pause();
	window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup1();
}
}

































};
obj1569_onTap_actionGroup1 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1569_onTap_activeActionGroupIndex = -1;
		$("#obj1569").trigger("obj1569_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1569) {
				console.warn("de-queueing event obj1569." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1569").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1569_onTap_activeActionGroupIndex = 1;
	

//	action: hide
//	selector: obj#obj1566 
hide_1572();
function hide_1572() {
	var selector = "#obj1566";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj1569_onTap_runningActionsCount = obj1569_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup2();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_1572(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup2();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj1569_onTap_actionGroup2 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1569_onTap_activeActionGroupIndex = -1;
		$("#obj1569").trigger("obj1569_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1569) {
				console.warn("de-queueing event obj1569." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1569").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1569_onTap_activeActionGroupIndex = 2;
	

//	action: hide
//	selector: obj#obj1569 
hide_1579();
function hide_1579() {
	var selector = "#obj1569";
	$(selector).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
	window.obj1569_onTap_runningActionsCount = obj1569_onTap_runningActionsCount + 1;

	
	var animationType = "";
	var animationDurationMs = 1000;
	var animationIterationCount = "1";

	if ($(selector).css("display") == "none" || animationType == "" || animationDurationMs == 0) {
		setTimeout(function() {
			$(selector).css("display", "none");
			window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup3();
}
		}, 1);
		return;
	};

	$(selector).css("animation-duration", animationDurationMs + "ms");
	$(selector).css("animation-iteration-count", animationIterationCount);

	if ($(selector).attr("sccurrentanimation") != null) {
		$(selector).trigger("animationend", $(selector).attr("sccurrentanimation"));
		setTimeout(hide_1579(), 100);
		return;
	}

	setTimeout(function() {
		$(selector).css("display", "none");
		window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup3();
}
	}, animationDurationMs);

	$(selector).addClass("animated " + animationType);

}









































};
obj1569_onTap_actionGroup3 = function(){
	isLastActionGroup = false;
	if (isLastActionGroup) {
		window.obj1569_onTap_activeActionGroupIndex = -1;
		$("#obj1569").trigger("obj1569_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1569) {
				console.warn("de-queueing event obj1569." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1569").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1569_onTap_activeActionGroupIndex = 3;
	


//	action: show 
//	selector: #obj889
(function(){
	window.obj1569_onTap_runningActionsCount = obj1569_onTap_runningActionsCount + 1;


	var selector = "#obj889";
	if ($(selector).hasClass("SCImage")) {
		var lastIndex = $(selector).length-1;
		$(selector).each(function (index, element) {
			if ($(element).hasClass("SCImage")) {
				try {
					const img = $("img", element)[0];
					img.decode()
						.then(function() { showObject(element, index == lastIndex); })
						.catch(function(encodingError) {
							console.error(encodingError);
							showObject(element, index == lastIndex);
						});
				} catch (err) {
					showObject(element, index == lastIndex);
				}
			} else {
				showObject(element, index == lastIndex);
			}
		});
	} else {
		showObject(selector, true);
	}
	
	function showObject(element, isLast) {
		$(element).removeClass("animated bounce flash pulse rubberBand shake headShake swing tada wobble jello bounceIn bounceInDown bounceInLeft bounceInRight bounceInUp bounceOut bounceOutDown bounceOutLeft bounceOutRight bounceOutUp fadeIn fadeInDown fadeInDownBig fadeInLeft fadeInLeftBig fadeInRight fadeInRightBig fadeInUp fadeInUpBig fadeOut fadeOutDown fadeOutDownBig fadeOutLeft fadeOutLeftBig fadeOutRight fadeOutRightBig fadeOutUp fadeOutUpBig flipInX flipInY flipOutX flipOutY lightSpeedIn lightSpeedOut rotateIn rotateInDownLeft rotateInDownRight rotateInUpLeft rotateInUpRight rotateOut rotateOutDownLeft rotateOutDownRight rotateOutUpLeft rotateOutUpRight hinge jackInTheBox rollIn rollOut zoomIn zoomInDown zoomInLeft zoomInRight zoomInUp zoomOut zoomOutDown zoomOutLeft zoomOutRight zoomOutUp slideInDown slideInLeft slideInRight slideInUp slideOutDown slideOutLeft slideOutRight slideOutUp heartBeat");
	
		var animationType = "";
		var animationDurationMs = 1000;
		var animationIterationCount = "1";
	
		if ($(element).css("display") == "block" || animationType == "" || animationDurationMs == 0) {
			setTimeout(function() {
				$(element).css("display", "block");
				if (isLast) {
					window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup4();
}
				}
				$(element).trigger('SCEventShow');
			}, 1);
			return;
		};
	
		$(element).css("animation-duration", animationDurationMs + "ms");
		$(element).css("animation-iteration-count", animationIterationCount);
	
		setTimeout(function() {
			$(element).css("display", "block");
			$(element).removeClass("animated " + animationType);
			if (isLast) {
				window.obj1569_onTap_runningActionsCount = window.obj1569_onTap_runningActionsCount - 1;

if (window.obj1569_onTap_runningActionsCount < 0) {
	window.obj1569_onTap_runningActionsCount = 0;
} else if (window.obj1569_onTap_runningActionsCount == 0) {
	obj1569_onTap_actionGroup4();
}
			}
			$(element).trigger('SCEventShow');
		}, animationDurationMs);
	
		$(element).addClass("animated " + animationType);
		$(element).css("display", "block");
	}
})();








































};
obj1569_onTap_actionGroup4 = function(){
	isLastActionGroup = true;
	if (isLastActionGroup) {
		window.obj1569_onTap_activeActionGroupIndex = -1;
		$("#obj1569").trigger("obj1569_onTap_ended");
		

		for (var i = 0; i < pubcoder.queuedEvents.length; i++) {
			const evt = pubcoder.queuedEvents[i];
			if (evt.senderObjectId == 1569) {
				console.warn("de-queueing event obj1569." + evt.eventName);
				pubcoder.queuedEvents.splice(i, 1);
				$("#obj1569").trigger(evt.eventName);
				return;
			}
		}
		return;
	}
	window.obj1569_onTap_activeActionGroupIndex = 4;
	











































};
		

		/*
		 *
	 	 *  Events
	 	 *
	 	 */
		

















































































/*
 *
 *   obj883: Event Touch Down
 *
 */

$("#obj883").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj883_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj883_onTap is still running");
	return;
}
var obj883_onTap_runningActionsCount = 0;
var obj883_onTap_loopCount = 0;
obj883_onTap_actionGroup0();
});


















/*
 *
 *   obj889: Event Touch Down
 *
 */

$("#obj889").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj889_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj889_onTap is still running");
	return;
}
var obj889_onTap_runningActionsCount = 0;
var obj889_onTap_loopCount = 0;
obj889_onTap_actionGroup0();
});
























































/*
 *
 *   obj1569: Event Touch Down
 *
 */

$("#obj1569").bind(PubCoder.Events.Tap, function(event) {
	event.preventDefault();	
	if (window.obj1569_onTap_activeActionGroupIndex != -1) {
	console.warn("action list window.obj1569_onTap is still running");
	return;
}
var obj1569_onTap_runningActionsCount = 0;
var obj1569_onTap_loopCount = 0;
obj1569_onTap_actionGroup0();
});


























































































		
		
		/*
		 *
	 	 *  Page is ready to be played
	 	 *
	 	 */
		XPUB.ready();
	 }
});

$(window).on(pubcoder.events.pagePlay, function() {
	$(window).trigger(pubcoder.events.pageReady);
	if (pubcoder.isInteractionObserverSupported) {
		var ob = new IntersectionObserver(function(entries) {
			$(entries).each(function (index, entry) {
				if (entry.isIntersecting) {
					$(entry.target).trigger(pubcoder.events.appear);
				} else {
					$(entry.target).trigger(pubcoder.events.disappear);
				}
			});
		}, {
			root: null,
			rootMargin: "0px",
			threshold: 0
		});
		$(".SCView").each(function (i, el) {
			ob.observe(el);
		});	
	}
	
$("#obj5").trigger('SCEventShow');
$("#obj877").trigger('SCEventShow');
$("#obj29").trigger('SCEventShow');
$("#obj885").trigger('SCEventShow');
$("#obj883").trigger('SCEventShow');
$("#obj889").trigger('SCEventShow');
$("#obj920").trigger('SCEventShow');
$("#obj7994").trigger('SCEventShow');
$("#obj7996").trigger('SCEventShow');
$("#obj7998").trigger('SCEventShow');
$("#obj8000").trigger('SCEventShow');
	

});